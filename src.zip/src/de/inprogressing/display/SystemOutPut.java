package de.inprogressing.display;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SystemOutPut {

    public static void print(String msg) {
        String time = new SimpleDateFormat("HH:mm:ss").format(new Date());
        System.out.println("["+time+"] " + msg);
    }
}
