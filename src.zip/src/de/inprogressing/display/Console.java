package de.inprogressing.display;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Console {

    public static  int CreatedLInes = 0;
    public static int linex;
    public static String format = "[time] msg";
    public static String TimeFormat = "HH:mm:ss";
    
    public static ArrayList<String> publicSP = new ArrayList<>();
    public static ArrayList<String> drawStrings = new ArrayList<>();

    public static void AddConsole(String msg){
        CreatedLInes++;
        String time = new SimpleDateFormat(TimeFormat).format(new Date());

        //Not Error
        msg = msg.replaceAll("next", "");

        //Add msg
        String add = format;
        add = add.replaceAll("time", time);
        add = add.replaceAll("msg", msg);
        publicSP.add(add);
        DrawStrings(0, false);
    }

    public static void clear(){
        //Clear publicSP
        publicSP.clear();
        drawStrings.clear();
        CreatedLInes = 0;
    }

    public static void DrawStrings(int line, boolean canline){
        if(!canline) {
            linex = Window.j.getHeight() / 17;
        } else {
            linex = line;
        }

        drawStrings.clear();
        if(publicSP.size() <= linex){
            for (int i = 0; i < publicSP.size(); i++) {
                drawStrings.add(publicSP.get(i));
            }
        } else {
            for (int i = publicSP.size()-linex; i < publicSP.size(); i++) {
                drawStrings.add(publicSP.get(i));
            }
        }
    }
}
