package de.inprogressing.display;

import java.awt.Color;

public class Start {
	
    public static void StartProgramm(){
    	SystemOutPut.print("Started Program");

        new Window();
        new Timerx();
    }
    
    public static void setFormat(String format) {
    	Console.format = format;
    }
    
    public static void setTimeFormat(String format) {
    	Console.TimeFormat = format;
    }
    
    public static void setRainbowColorSpeed(int runs) {
    	RainbowColor.run = runs;
    }
    
    public static void setRainbowColor(boolean rain) {
    	RainbowColor.RainbowColor = rain;
    }
    
    public static void setScreen(int width, int height) {
    	Window.width = width;
    	Window.height = height;
    }
    
    public static void StartRainbowColor() {
    	new RainbowColor();
    }
    
    public static void setColorForderground(Color color) {
    	if(!Draw.ColorForderground) {
    		Draw.ColorForderground = true;
    	}
    	Draw.ColorFor = color;
    }
    
    public static void setColorBackground(Color color) {
    	if(!Draw.ColorBackground) {
    		Draw.ColorBackground = true;
    	}
    	Draw.ColorBack = color;
    }
    
    public static void setColorFordergroundDefault() {
    	Draw.ColorFor = Color.WHITE;
    	Draw.ColorForderground = false;
    }
    
    public static void setColorBackgroundDefault() {
    	Draw.ColorBack = Color.BLACK;
    	Draw.ColorBackground = false;
    }
}
