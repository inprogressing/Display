package de.inprogressing.display;
import javax.swing.*;
import java.awt.*;

@SuppressWarnings("serial")
public class Draw extends JLabel {

    long firstFrame = 0;
    int frames = 0;
    long currentFrame;
    int fps;

    public static Color TextColor = Color.WHITE;
    public static Color ColorFor = Color.WHITE;
    public static boolean ColorForderground = false;
    
    public static Color ColorBack = Color.BLACK;
    public static boolean ColorBackground = false;
    
    protected void paintComponent(Graphics g){

        super.paintComponent(g);

        Graphics2D g2d = (Graphics2D) g;

        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g.setColor(Color.BLACK);
        if(ColorBackground) {
        	g.setColor(ColorBack);
        }
        g.fillRect(0, 0, Window.j.getWidth(), Window.j.getHeight());

        g.setColor(TextColor);

        if(RainbowColor.RainbowColor){
            g.setColor(RainbowColor.c1);
        }

        if(ColorForderground) {
        	g.setColor(ColorFor);
        }
        
        int ys = 20;

        Font FONT = new Font("Impact", Font.PLAIN, 13);
        g.setFont(FONT);

        for(int i=0;i<Console.drawStrings.size();i++) {
            if(Console.drawStrings.get(i) != null) {
            g.drawString(Console.drawStrings.get(i), 10, ys);
            ys += 15;
            }
        }

        g.drawString("Line: " + String.valueOf(Console.CreatedLInes), Window.j.getWidth() - 100, 20);
        
        repaint();

    }
}
