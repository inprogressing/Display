package de.inprogressing.display;
import java.util.Timer;
import java.util.TimerTask;

public class Timerx {
    Timer move;

    public static int line = 48;

    public Timerx() {
        move = new Timer();
        move.scheduleAtFixedRate(new TimerTask(){

            @Override
            public void run() {
                if(KeyHandler.up){
                    line++;
                    Console.DrawStrings(line, true);
                }

                if(KeyHandler.down){
                    line--;
                    Console.DrawStrings(line, true);
                }
            }
        }, 0,50);
    }
}
