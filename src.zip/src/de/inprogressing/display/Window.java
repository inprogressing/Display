package de.inprogressing.display;
import javax.swing.*;
public class Window {

    //public static int width = 1920, height = 1080;
    public static int width = 1440, height = 810;
    //public static int width = 960, height = 540;
    // public static int width = 480, height = 270;

    public static JFrame j = new JFrame();

    public Window(){
        SystemOutPut.print("Creating Window...");

        j.setVisible(true);
        j.setSize(width, height);
        j.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        j.setTitle("Console-new");
        
        SystemOutPut.print("Creating Window -> Add Draw...");
        Draw lbldraw = new Draw();
        lbldraw.setBounds(0,0, width, height);
        lbldraw.setVisible(true);
        j.add(lbldraw);
        SystemOutPut.print("Creating Window -> Added Draw");

        SystemOutPut.print("Creating Window -> Add KeyHandler...");
        j.addKeyListener(new KeyHandler());
        SystemOutPut.print("Creating Window -> Added KeyHandler");

        SystemOutPut.print("Created Window");
    }
}
