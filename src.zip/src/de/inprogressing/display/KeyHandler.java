package de.inprogressing.display;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyHandler implements KeyListener {

    public static boolean up = false;
    public static boolean down = false;

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {

        if(e.getKeyCode() == KeyEvent.VK_UP){
            up = true;
        }

        if(e.getKeyCode() == KeyEvent.VK_DOWN){
            down = true;
        }

        if(e.getKeyCode() == KeyEvent.VK_ESCAPE){
            Runtime.getRuntime().exit(0);
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {

        if(e.getKeyCode() == KeyEvent.VK_UP) {
            up = false;
        }

        if(e.getKeyCode() == KeyEvent.VK_DOWN){
            down = false;
        }
    }
}
