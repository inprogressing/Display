package de.inprogressing.display;
import java.awt.*;

public class RainbowColor {

    public static boolean RainbowColor = true;
    public static  int run = 100;
    public static Color c1;

    public RainbowColor(){

        if(RainbowColor) {
            try {
                while (true) {
                    for (int i = 0; i < 255; i++) {
                        c1 = new Color(255, i, 0, 255);
                        Thread.sleep(run);
                    }

                    for (int i = 255; i > 0; i--) {
                        c1 = new Color(i, 255, 0, 255);
                        Thread.sleep(run);
                    }

                    for (int i = 0; i < 255; i++) {
                        c1 = new Color(0, 255, i, 255);
                        Thread.sleep(run);
                    }

                    for (int i = 255; i > 0; i--) {
                        c1 = new Color(0, i, 255, 255);
                        Thread.sleep(run);
                    }

                    for (int i = 0; i < 255; i++) {
                        c1 = new Color(i, 0, 255, 255);
                        Thread.sleep(run);
                    }

                    for (int i = 255; i > 0; i--) {
                        c1 = new Color(255, 0, i, 255);
                        Thread.sleep(run);
                    }
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
                SystemOutPut.print("Error src/RainbowColor/InterruptedException");
            }
        }

    }
}
